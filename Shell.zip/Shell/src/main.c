/**
 * @file main.c
 * @brief This is the main file for the shell. It contains the main function and the loop that runs the shell.
 * @version 0.1
 * @date 2023-06-02
 *
 * @copyright Copyright (c) 2023
 *
 */
#include <utils.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For chdir
#include <stdbool.h>
#include <sys/wait.h> // Include this header for waitpid
#include <fcntl.h>

#define MAX_INPUT_LENGTH 1024
// BETA

// Data structure to store aliases
#define MAX_ALIAS_COUNT 50
struct Alias
{
    char aliasName[MAX_INPUT_LENGTH];
    char aliasValue[MAX_INPUT_LENGTH];
};
void removeQuotes(char *input)
{
    int length = strlen(input);
    char result[length];
    int resultIndex = 0;

    for (int i = 0; i < length; i++)
    {
        if (input[i] != '"' && input[i] != '\'')
        {
            result[resultIndex++] = input[i];
        }
    }

    result[resultIndex] = '\0';

    strcpy(input, result);
}

void executeExternalCommand(char *command)
{
    pid_t child_pid;
    int child_status;
    removeQuotes(command);

    // Fork a child process
    child_pid = fork();

    if (child_pid == -1)
    {
        perror("Fork failed");
        return;
    }

    if (child_pid == 0)
    {
        // Child process

        // Parse the command to check for redirection operators
        char *args[1024]; // Adjust the array size as needed
        int arg_count = 0;

        char *token = strtok(command, " ");
        if (strcmp(token, "echo")){printf("OOP\n");}
        
        while (token != NULL)
        {
            if (strcmp(token, ">") == 0)
            {
                token = strtok(NULL, " ");
                if (token != NULL)
                {
                    int fd = open(token, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                    
                    if (fd == -1)
                    {
                        perror("Error opening output file");
                        exit(EXIT_FAILURE);
                    }
                    if (dup2(fd, STDOUT_FILENO) == -1)
                    {
                        perror("Error redirecting output");
                        exit(EXIT_FAILURE);
                    }
                    
                    close(fd);
                    token = strtok(NULL, " "); //
                }
                else
                {
                    fprintf(stderr, "Missing output file name after '>'\n");
                    exit(EXIT_FAILURE);
                }
            }
            // Check for input redirection
            else if (strcmp(token, "<") == 0)
            {
                token = strtok(NULL, " ");
                if (token != NULL)
                {
                    int fd = open(token, O_RDONLY);
                    
                    if (fd == -1)
                    {
                        perror("Error opening input file");
                        exit(EXIT_FAILURE);
                    }
                    if (dup2(fd, STDIN_FILENO) == -1)
                    {
                        perror("Error redirecting input");
                        exit(EXIT_FAILURE);
                    }
                    close(fd);
                    token = strtok(NULL, " "); // 
                }
                else
                {
                    fprintf(stderr, "Missing input file name after '<'\n");
                    exit(EXIT_FAILURE);
                }
            }
            // Check for appending output redirection (>>)
else if (strcmp(token, ">>") == 0)
{
    token = strtok(NULL, " ");
    if (token != NULL)
    {
        int fd = open(token, O_WRONLY | O_CREAT | O_APPEND, 0644);
        
        if (fd == -1)
        {
            perror("Error opening output file for appending");
            exit(EXIT_FAILURE);
        }
        if (dup2(fd, STDOUT_FILENO) == -1)
        {
            perror("Error redirecting output");
            exit(EXIT_FAILURE);
        }
        
        close(fd);
        token = strtok(NULL, " "); // Skip the filename
    }
    else
    {
        fprintf(stderr, "Missing output file name after '>>'\n");
        exit(EXIT_FAILURE);
    }
}

            else
            {
                args[arg_count] = token;
                arg_count += 1;
                token = strtok(NULL, " ");
            }
        }

        args[arg_count] = NULL; //
        
         
        // Execute the command
        if (execvp(args[0], args) == -1)
        {
            perror("Execution failed");
            exit(EXIT_FAILURE);
        }
    
    }
    else
    {
        // Parent process

        // Wait for the child process to complete
        waitpid(child_pid, &child_status, 0);

        if (WIFEXITED(child_status))
        {
            // printf("Child process exited with status %d\n", WEXITSTATUS(child_status));
        }
    }
}


int main(int argc, char *argv[])
{
    // bool shell = false;
    char input[MAX_INPUT_LENGTH];
    char *history[MAX_INPUT_LENGTH]; // Array to store command history
    int historyCount = 0;
    char comm[1024];

    // Array to store aliases
    struct Alias aliases[1024];
    int aliasCount = 0;
    if (argc > 1)
    {

        FILE *scriptFile = fopen(argv[1], "r"); // Open the script file for reading

        if (scriptFile == NULL)
        {
            perror("Error opening script file");
            return 1;
        }

        char line[1024];
        // char next[1024];

        // Read and execute commands from the script file
        while (fgets(line, sizeof(line), scriptFile) != NULL)
        {
            // printf("%s", line); // Print the line
            bool fl = true;

            // Remove the trailing newline character
            line[strcspn(line, "\n")] = '\0';
            strcpy(comm, line);
            int wordCount = 0;
            bool inWord = false;
            for (int i = 0; comm[i] != '\0'; i++)
            {
                if (comm[i] == ' ' || comm[i] == '\t' || comm[i] == '\n')
                {
                    // We are in whitespace, so not in a word
                    inWord = false;
                }
                else
                {
                    if (!inWord)
                    {
                        wordCount++;
                        inWord = true;
                    }
                }
            }
            // Add the command to history
            history[historyCount] = strdup(line);
            historyCount++;

            while (fl)
            {

                //
                // char* ok = history[];
                char *parsed = strtok(line, " ");

                // Check for built-in commands
                if (parsed != NULL)
                {
                    // EXIT
                    bool als = false;
                    for (int i = 0; i < aliasCount; i++)
                    {
                        if (strcmp(parsed, aliases[i].aliasName) == 0)
                        {
                            if (wordCount <= 1)
                            {
                                strcpy(parsed, aliases[i].aliasValue);
                                parsed = strtok(parsed, " ");
                                strcpy(comm, aliases[i].aliasValue);
                                als = true;
                                break;
                            }
                        }
                    }

                    // }
                    if (als)
                    {
                        printf("found alias----\n\n");
                    }

                    if (strcmp(parsed, "exit") == 0)
                    {
                        // printf("EXITED BYE\n");
                        fl = false;
                        // Free history memory
                        for (int i = 0; i < historyCount; i++)
                        {
                            free(history[i]);
                        }
                        return 0;
                        // pwd
                    }
                    else if (strcmp(parsed, "pwd") == 0)
                    {
                        char cwd[MAX_INPUT_LENGTH];
                        if (getcwd(cwd, sizeof(cwd)) != NULL)
                        {
                            printf("%s\n", cwd);
                        }
                        else
                        {
                            perror("getcwd");
                        }
                        fl = false;
                        // cd
                    }
                    else if (strcmp(parsed, "cd") == 0)
                    {
                        // Change directory
                        parsed = strtok(NULL, " ");
                        if (parsed != NULL)
                        {
                            if (chdir(parsed) != 0)
                            {
                                perror("could not change directory");
                            }
                        }
                        else
                        {
                            parsed = "/home";
                            chdir(parsed);
                            printf("Directory switched to home\n");
                        }
                        fl = false;
                        // echo
                    }
                     else if (strcmp(parsed, ">") == 0 || strcmp(parsed, ">>") == 0)
                    {
                        // Handle I/O redirection
                        // handleRedirection(comm);
                        executeExternalCommand(comm);
                        fl = false;
                    }

                        else if (strcmp(parsed, "echo") == 0)
                        {
                                
                            // Print the rest of the input
                            while ((parsed = strtok(NULL, " ")) != NULL)
                            {
                                if (strcmp(parsed, ">") == 0)
                                {
                                    break;
                                   
                                }
                                if (strcmp(parsed, ">>") == 0)
                                {
                                    break;
                                    
                                }
                                if (parsed[0] == '"')
                                {
                                    int length = strlen(parsed);
                                    char *new = parsed;
                                    for (int i = 0; i < length; i++)
                                    {
                                        parsed[i] = new[i + 1];
                                    }
                                    // printf("%s\n", parsed+1);
                                }
                                if (parsed[strlen(parsed) - 1] == '"')
                                {
                                    parsed[strlen(parsed) - 1] = '\0';
                                }
                                printf("%s ", parsed);
                                // Skip "echo "
                            }
                            printf("\n");
                            fl = false;
                        }

                        else if (strcmp(parsed, "alias") == 0)
                        {
                            parsed = strtok(NULL, " ");
                            //    char string[20];
                            // strcpy(string, parsed);
                            // printf("String: %s\n", string);
                            if (parsed != NULL)
                            {
                                char *aliasName = parsed;
                                parsed = strtok(NULL, "\"");
                                if (parsed != NULL)
                                {

                                    // Remove quotes from the alias value
                                    int length = strlen(parsed);
                                    if (parsed[length - 1] == '"')
                                    {
                                        parsed[length - 1] = '\0';
                                    }
                                    // Store the alias in the array
                                    if (aliasCount < MAX_ALIAS_COUNT)
                                    {
                                        strcpy(aliases[aliasCount].aliasName, aliasName);
                                        strcpy(aliases[aliasCount].aliasValue, parsed);
                                        aliasCount++;
                                    }
                                    else
                                    {
                                        printf("Maximum alias count reached.\n");
                                    }
                                }
                                else
                                {
                                    bool found = false;
                                    for (int i = 0; i < aliasCount; i++)
                                    {
                                        if (strcmp(aliasName, aliases[i].aliasName) == 0)
                                        {
                                            found = true;
                                            printf("%s='%s'\n", aliases[i].aliasName, aliases[i].aliasValue);
                                        }
                                        // printf("Invalid alias format\n");
                                    }
                                    if (!found)
                                    {
                                        printf("Currently, No such Alias exists\n");
                                    }
                                }
                            }
                            else
                            {
                                // List all currently defined aliases
                                if (aliasCount == 0)
                                {
                                    printf("No alias created yet\n");
                                }
                                for (int i = 0; i < aliasCount; i++)
                                {
                                    printf("%s='%s'\n", aliases[i].aliasName, aliases[i].aliasValue);
                                }
                            }
                            fl = false;
                        }
                        else if (strcmp(parsed, "unalias") == 0)
                        {
                            parsed = strtok(NULL, " ");
                            int index;
                            //    char string[20];
                            // strcpy(string, parsed);
                            // printf("String: %s\n", string);
                            if (parsed != NULL)
                            {
                                char *aliasName = parsed;
                                bool found = false;
                                for (int i = 0; i < aliasCount; i++)
                                {
                                    if (strcmp(aliasName, aliases[i].aliasName) == 0)
                                    {
                                        found = true;
                                        index = i;
                                        printf("Deleting the following Alias: \n");
                                        printf("%s='%s'\n", aliases[index].aliasName, aliases[i].aliasValue);
                                    }
                                }
                                if (!found)
                                {
                                    printf("Currently, No such Alias exists\n");
                                }
                                else
                                {
                                    if (index != -1)
                                    {
                                        // Shift elements to the left to overwrite the removed element
                                        for (int i = index; i < aliasCount - 1; i++)
                                        {
                                            strcpy(aliases[i].aliasName, aliases[i + 1].aliasName);
                                            strcpy(aliases[i].aliasValue, aliases[i + 1].aliasValue);
                                        }

                                        // Decrement aliasCount to reflect the removal
                                        aliasCount--;
                                    }
                                }
                            }
                            else
                            {
                                printf("Invalid format\n");
                            }

                            fl = false;
                        }
                        else if (strcmp(parsed, "history") == 0)
                        {
                            // Display command history
                            for (int i = 0; i < historyCount; i++)
                            {
                                printf("%d %s\n", i + 1, history[i]);
                            }

                            // Check for optional index argument
                            parsed = strtok(NULL, " ");
                            if (parsed != NULL)
                            {
                                int index = atoi(parsed);
                                if (index >= 1 && index <= historyCount)
                                {
                                    printf("Executing from history: %s\n", history[index - 1]);
                                    parsed = history[index - 1];
                                    strcpy(line, parsed);
                                    // printf("parsed: %s\n", parsed);
                                    fl = true;
                                }
                                else
                                {
                                    printf("Invalid history index\n");
                                    fl = false;
                                }
                            }
                            else
                            {
                                fl = false;
                            }
                        }

                        else
                        {
                            // printf("command before EXEC Function = ");
                            // printf("%s ", comm);
                            // printf("\n\n");
                            executeExternalCommand(comm);
                            fl = false; // Set this to exit the inner while loop
                            // Add code to handle external commands
                            // The parsed variable contains the command name, and you can parse the rest of the input as arguments
                        }
                        //         if(output_redirect>0){
                        //         if (dup2(original_stdout, STDOUT_FILENO) == -1) {
                        //     perror("Error restoring stdout");

                        // }

                        // Close the duplicated file descriptor
                        // close(original_stdout);
                    }
                }
            }

            // Close the script file
            fclose(scriptFile);
            return 0;
        }

        else
        {

            bool exit = false;

            while (!exit)
            {
                bool fl = true;
                char com[1024];

                printf("Enter a command: ");
                fgets(input, sizeof(input), stdin);

                // Remove the trailing newline character
                input[strcspn(input, "\n")] = '\0';
                strcpy(com, input);
                // printf("%s\n", com);        // char* check = strdup(comm);
                bool inWord = false;
                int wordCount = 0;
                for (int i = 0; com[i] != '\0'; i++)
                {
                    if (com[i] == ' ' || com[i] == '\t' || com[i] == '\n')
                    {
                        // We are in whitespace, so not in a word
                        inWord = false;
                    }
                    else
                    {
                        // We are not in whitespace
                        if (!inWord)
                        {
                            // We just entered a new word
                            wordCount++;
                            inWord = true;
                        }
                    }
                }

                // printf("Number of pieces in this command are : %d \n", wordCount);

                // Add the command to history
                history[historyCount] = strdup(input);
                historyCount++;

                //     // void shell(){}
                //     // parse the input
                while (fl)
                {
                    char iocomm[1024];
                    strcpy(iocomm, com);
                    // IO
                    char comm[1024];
                    strcpy(comm, input);
                    int fd;
                    int original_stdout;
                    int output_redirect = 0; // 0: no output redirection, 1: '>', 2: '>>'
                    char *output_file = NULL;

                    // Check for output redirection
                    char *check = strtok(iocomm, " ");
                    while (check != NULL)
                    {
                        if (strcmp(check, ">") == 0)
                        {
                            output_redirect = 1; // Overwrite output file
                            check = strtok(NULL, " ");
                            if (check != NULL)
                            {
                                output_file = check;
                            }
                            else
                            {
                                printf("Missing output file name after '>'\n");
                                return 1;
                            }
                        }
                        else if (strcmp(check, ">>") == 0)
                        {
                            output_redirect = 2; // Append to output file
                            check = strtok(NULL, " ");
                            if (check != NULL)
                            {
                                output_file = check;
                            }
                            else
                            {
                                printf("Missing output file name after '>>'\n");
                                return 1;
                            }
                        }
                        else if (strcmp(check, "<") == 0)
                        {
                            output_redirect = 3; // Input redirection
                            check = strtok(NULL, " ");
                            if (check != NULL)
                            {
                                output_file = check;
                            }
                            else
                            {
                                printf("Missing input file name after '<'\n");
                                return 1;
                            }
                        }
                        else
                        {
                            check = strtok(NULL, " ");
                        }
                    }

                    if (output_redirect > 0 && output_file != NULL)
                    {
                        printf("IO\n");
                        if (output_redirect == 1)
                        {
                            fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644); // Overwrite
                        }
                        else if (output_redirect == 2)
                        {
                            fd = open(output_file, O_WRONLY | O_CREAT | O_APPEND, 0644); // Append
                        }
                        else if (output_redirect == 3)
                        {
                            fd = open(output_file, O_RDONLY); // Open the input file
                        }

                        if (fd == -1)
                        {
                            perror("Error opening output file");
                            return 1;
                        }

                        // Redirect stdout to the output file
                        original_stdout = dup(STDOUT_FILENO);

                        if (dup2(fd, STDOUT_FILENO) == -1)
                        {
                            perror("Error redirecting output");
                            close(fd);
                            return 1;
                        }
                        close(fd); // Close the file descriptor after redirection
                    }
                    char *parsed;
                    if (output_redirect == 1)
                    {
                        parsed = strtok(input, " >");
                    }
                    else if (output_redirect == 2)
                    {
                        parsed = strtok(input, " >>");
                    }
                    else if (output_redirect == 2)
                    {
                        parsed = strtok(input, " <");
                    }
                    else
                    {
                        parsed = strtok(input, " ");
                    }
                    // printf("parsed = ");
                    // printf("%s ", parsed);

                    // Check for built-in commands
                    if (parsed != NULL)
                    {
                        // bool found =false;
                        for (int i = 0; i < aliasCount; i++)
                        {
                            if (strcmp(parsed, aliases[i].aliasName) == 0)
                            {
                                // found =true;
                                if (wordCount <= 1)
                                {
                                    strcpy(parsed, aliases[i].aliasValue);
                                    strcpy(com, aliases[i].aliasValue);
                                    parsed = strtok(parsed, " ");
                                }
                            }
                        }

                        // EXIT
                        if (strcmp(parsed, "exit") == 0)
                        {
                            printf("EXITED BYE\n");
                            fl = false;
                            // Free history memory
                            for (int i = 0; i < historyCount; i++)
                            {
                                free(history[i]);
                            }
                            exit = true;
                            // pwd
                        }
                        else if (strcmp(parsed, "pwd") == 0)
                        {
                            char cwd[MAX_INPUT_LENGTH];
                            if (getcwd(cwd, sizeof(cwd)) != NULL)
                            {
                                printf("%s\n", cwd);
                            }
                            else
                            {
                                perror("getcwd");
                            }
                            fl = false;
                            // cd
                        }
                        else if (strcmp(parsed, "cd") == 0)
                        {
                            // Change directory
                            parsed = strtok(NULL, " ");
                            if (parsed != NULL)
                            {
                                if (chdir(parsed) != 0)
                                {
                                    perror("could not change directory");
                                }
                            }
                            else
                            {
                                parsed = "/home";
                                chdir(parsed);
                                printf("Directory switched to home\n");
                            }
                            fl = false;
                            // echo
                        }
                         else if (strcmp(parsed, ">") == 0 || strcmp(parsed, ">>") == 0)
                    {
                        // Handle I/O redirection
                        // handleRedirection(comm);
                        executeExternalCommand(comm);
                        fl = false;
                    }

                        else if (strcmp(parsed, "echo") == 0)
                        {
                                
                            // Print the rest of the input
                            while ((parsed = strtok(NULL, " ")) != NULL)
                            {
                                if (strcmp(parsed, ">") == 0)
                                {
                                    break;
                                   
                                }
                                if (strcmp(parsed, ">>") == 0)
                                {
                                    break;
                                    
                                }
                                if (parsed[0] == '"')
                                {
                                    int length = strlen(parsed);
                                    char *new = parsed;
                                    for (int i = 0; i < length; i++)
                                    {
                                        parsed[i] = new[i + 1];
                                    }
                                    // printf("%s\n", parsed+1);
                                }
                                if (parsed[strlen(parsed) - 1] == '"')
                                {
                                    parsed[strlen(parsed) - 1] = '\0';
                                }
                                printf("%s ", parsed);
                                // Skip "echo "
                            }
                            printf("\n");
                            fl = false;
                        }

                        else if (strcmp(parsed, "alias") == 0)
                        {
                            parsed = strtok(NULL, " ");
                            //    char string[20];
                            // strcpy(string, parsed);
                            // printf("String: %s\n", string);
                            if (parsed != NULL)
                            {
                                char *aliasName = parsed;
                                parsed = strtok(NULL, "\"");
                                if (parsed != NULL)
                                {

                                    // Remove quotes from the alias value
                                    int length = strlen(parsed);
                                    if (parsed[length - 1] == '"')
                                    {
                                        parsed[length - 1] = '\0';
                                    }
                                    // Store the alias in the array
                                    if (aliasCount < MAX_ALIAS_COUNT)
                                    {
                                        strcpy(aliases[aliasCount].aliasName, aliasName);
                                        strcpy(aliases[aliasCount].aliasValue, parsed);
                                        aliasCount++;
                                    }
                                    else
                                    {
                                        printf("Maximum alias count reached.\n");
                                    }
                                }
                                else
                                {
                                    bool found = false;
                                    for (int i = 0; i < aliasCount; i++)
                                    {
                                        if (strcmp(aliasName, aliases[i].aliasName) == 0)
                                        {
                                            found = true;
                                            printf("%s='%s'\n", aliases[i].aliasName, aliases[i].aliasValue);
                                        }
                                        // printf("Invalid alias format\n");
                                    }
                                    if (!found)
                                    {
                                        printf("Currently, No such Alias exists\n");
                                    }
                                }
                            }
                            else
                            {
                                // List all currently defined aliases
                                if (aliasCount == 0)
                                {
                                    printf("No alias created yet\n");
                                }
                                for (int i = 0; i < aliasCount; i++)
                                {
                                    printf("%s='%s'\n", aliases[i].aliasName, aliases[i].aliasValue);
                                }
                            }
                            fl = false;
                        }
                        else if (strcmp(parsed, "unalias") == 0)
                        {
                            parsed = strtok(NULL, " ");
                            int index;
                            //    char string[20];
                            // strcpy(string, parsed);
                            // printf("String: %s\n", string);
                            if (parsed != NULL)
                            {
                                char *aliasName = parsed;
                                bool found = false;
                                for (int i = 0; i < aliasCount; i++)
                                {
                                    if (strcmp(aliasName, aliases[i].aliasName) == 0)
                                    {
                                        found = true;
                                        index = i;
                                        printf("Deleting the following Alias: \n");
                                        printf("%s='%s'\n", aliases[index].aliasName, aliases[i].aliasValue);
                                    }
                                }
                                if (!found)
                                {
                                    printf("Currently, No such Alias exists\n");
                                }
                                else
                                {
                                    if (index != -1)
                                    {
                                        // Shift elements to the left to overwrite the removed element
                                        for (int i = index; i < aliasCount - 1; i++)
                                        {
                                            strcpy(aliases[i].aliasName, aliases[i + 1].aliasName);
                                            strcpy(aliases[i].aliasValue, aliases[i + 1].aliasValue);
                                        }

                                        // Decrement aliasCount to reflect the removal
                                        aliasCount--;
                                    }
                                }
                            }
                            else
                            {
                                printf("Invalid format\n");
                            }

                            fl = false;
                        }
                        else if (strcmp(parsed, "history") == 0)
                        {
                            // Display command history
                            for (int i = 0; i < historyCount; i++)
                            {
                                printf("%d %s\n", i + 1, history[i]);
                            }

                            // Check for optional index argument
                            parsed = strtok(NULL, " ");
                            if (parsed != NULL)
                            {
                                int index = atoi(parsed);
                                if (index >= 1 && index <= historyCount)
                                {
                                    printf("Executing from history: %s\n", history[index - 1]);
                                    parsed = history[index - 1];
                                    strcpy(input, parsed);
                                    // printf("parsed: %s\n", parsed);
                                    fl = true;
                                }
                                else
                                {
                                    printf("Invalid history index\n");
                                    fl = false;
                                }
                            }
                            else
                            {
                                fl = false;
                            }
                        }

                        else
                        {
                            //  printf("command before execute function = ");
                            // printf("%s ", com);
                            // printf("\n\n");
                            if (output_redirect > 0)
                            {
                                executeExternalCommand(parsed);
                            }
                            else
                            {
                                executeExternalCommand(com);
                            }
                            // printf("trying external\n");
                            fl = false;
                            // printf("Unknown command\n");

                            // Add code to handle external commands
                            // The parsed variable contains the command name, and you can parse the rest of the input as arguments
                        }
                        if (output_redirect > 0)
                        {
                            if (dup2(original_stdout, STDOUT_FILENO) == -1)
                            {
                                perror("Error restoring stdout");
                            }

                            // Close the duplicated file descriptor
                            close(original_stdout);
                        }
                    }
                }
            }
            return 0;
        }
        return 0;
    }
